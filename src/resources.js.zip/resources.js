
// https://danburzo.ro/dom-gestures/
let gesture = false;
containerEl.addEventListener('gesturestart', e => {
  console.log(e.type);
  if (e.cancelable !== false) {
    e.preventDefault();
  }
  
  if (!gesture) {
    startGesture({
      translation: { x: 0, y: 0 },
      scale: e.scale,
      rotation: e.rotation,
      origin: { x: e.clientX, y: e.clientY }
    });
    gesture = true;
  } 
}, { passive: false });


containerEl.addEventListener('gesturechange', e => {
  if (e.cancelable !== false) {
    e.preventDefault();
  }
  if (gesture) {
    doGesture({
      translation: { x: 0, y: 0 },
      scale: e.scale,
      rotation: e.rotation,
      origin: { x: e.clientX, y: e.clientY }
    });
  }
}, { passive: false });

containerEl.addEventListener('gestureend', e => {
  console.log(e.type);
  //if (gesture) {
  
    endGesture({
      translation: { x: 0, y: 0 },
      scale: e.scale,
      rotation: e.rotation,
      origin: { x: e.clientX, y: e.clientY }
    });
   
  //	gesture = false;
//	}
});


  private connectPoints(x1: number, y1: number, x2: number, y2: number, svg: SVGSVGElement) {
    
    svg.createSvg("line", {
      attr: {
        x1: x1,  // Start x
        y1: y1,  // Start y
        x2: x2, // Slutt x
        y2: y2, // Slutt y
        stroke: "var(--bases-table-header-color)", // Bruker Obsidians fargetema
          "stroke-width": 0.5
      },
    });
  };

  private drawcurve(svg: SVGSVGElement) {

    // Q (Quadratic Bézier): M (start) Q (control point) (end point).
    // M x y: (Move) Flytter "pennen" til startpunktet.
    // Q x1 y1, x y: (Quadratic) Lager en bue med ett kontrollpunkt.
    // C (Cubic Bézier): M (start) C (control point 1) (control point 2) (end point). 
    //          (Cubic) Lager en mer kompleks bue med to kontrollpunkter, som en S-kurve.
    // A: (Arc) Brukes for å tegne deler av en sirkel eller ellipse

    const pathData = ""
      +   " M 0, 40"
      +  " L 20, 40"
      +  " Q 25, 41"
      +    " 25, 47"
      +  " L 25, 60"
      +  " Q 25, 66"
      +    " 32, 66"
      + " L 100, 66"; 

    svg.createSvg("path", {
      attr: {
        d: pathData,
        stroke: "var(--bases-table-header-color)", // Bruker Obsidians fargetema
          "stroke-width": 0.5,
        fill: "transparent"
      },
    });
  }


  // collective collapse all button
  private plotCollapseAllBtn (
              defaultCollapsed: boolean = true,
              parentEl: HTMLElement ) : HTMLElement {
  
    const btnCollapseAll = this.containerEl.createDiv(defaultCollapsed
      ? 'bases-relatednodes-btn-collapse-all collapsed'
      : 'bases-relatednodes-btn-collapse-all');
    setIcon(btnCollapseAll, defaultCollapsed ? 'chevrons-right': 'chevrons-down'); 
    
    btnCollapseAll.addEventListener('click', () => {
      const collapsed = btnCollapseAll.hasClass('collapsed');
      btnCollapseAll.toggleClass('collapsed', !collapsed);
      setIcon(btnCollapseAll, collapsed ? 'chevrons-down' : 'chevrons-right')
      parentEl.querySelectorAll(':scope > div').forEach(
        (x) => { 
          x.toggleClass('collapsed', !collapsed);
          x.querySelectorAll(':scope > ul').forEach(
            (y) => { 
              y.toggleClass('collapsed', !collapsed);
            }
          )
        }
      )
      parentEl.querySelectorAll('span').forEach(
        (x) => { 
          if (x.hasClass('bases-relatednodes-group-heading-icon')) {
            let iconDiv = x as HTMLElement;
            setIcon(iconDiv, collapsed ? 'chevron-down' : 'chevron-right');
          }
        }
      )
    });
    return btnCollapseAll;
  };

  private drawHalfCircle(x1: number, y1: number, direction: Direction, fill: ColorComponent, svg: SVGSVGElement) {

    /*
    d="M 10 70 a 60 60 0 1 0 120 0 Z"

    M 10 70: Move to (start point) (x=10, y=70).
    a 60 60 0 1 0 120 0: Arc command.
    60 60: X and Y radius of the arc.
    0: X-axis rotation (usually 0 for circles/semicircles).
    1: Large arc flag (1 to draw the longer arc, 0 for shorter; we need the longer half).
    0: Sweep flag (0 for anti-clockwise, 1 for clockwise).
    120 0: End point (relative to start point, 120 units right, 0 units vertically).
    Z: Close the path, drawing a straight line back to the start point,
    */

    const xrad = 3;
    const yrad = 3;
    const rot = () => {
      switch (direction) {
        case "up": return "1 6 0";
        case "right": return "1 0 6";
        case "down": return "0 6 0";
        case "left": "0 0 6";
        default: return "1 6 0";
      }
    }

    const pathData = `M ${x1} ${y1} a ${xrad} ${yrad} 0 0 ${rot()} Z`;

    svg.createSvg("path", {
      attr: {
        d: pathData,
        stroke: "var(--bases-table-header-color)", // Bruker Obsidians fargetema
          "stroke-width": 1,
        fill: "transparent"
      },
    });
  }

private diagonalLine(el: HTMLElement, color: string, thick: number) {
  
  const offset: Point = {
    x: window.pageXOffset-this.offBy!.x, 
    y: window.pageYOffset-this.offBy!.y
  }
  const rect = el.getBoundingClientRect();
  if (rect) {
    const svg = el.createSvg("svg", {
      attr: {
        width: rect.width,
        height: rect.height,
        style: `position: absolute; z-index: 50; left: ${window.pageXOffset}; top: ${window.pageYOffset}; `
      }
    });
    console.log("x", rect.x, "y", rect.y,"x2", offset.x + rect.width, "y2", offset.y + rect.height);
    console.log("window.pageXOffset X:", window.pageXOffset, "Y: ", window.pageYOffset);
    svg.createSvg("line", {
      attr: {
        x1: 0,  // Start x
        y1: 0,  // Start y
        x2: rect.width, // Slutt x
        y2: rect.height, // Slutt y
        stroke: color, // Bruker Obsidians fargetema
          "stroke-width": thick
      },
    });

  } else {
    console.log ("nope")
  }
  
  }

  //get active view - tips fra excalidraw
/*
    const addFieldToOntology = (checking: boolean, direction: Ontology | "select"):boolean => {
      const activeView = this.app.workspace.activeLeaf?.view;
      let editor: Editor;

      if(!activeView) {
        return false;
      }
  
      const viewType = activeView.getViewType();
      if(viewType === "excalidraw") {
        const leafOrNode = this.EA.getActiveEmbeddableViewOrEditor(activeView);
        
        if(!leafOrNode) {
          return false;
        }

        if("view" in leafOrNode && "editor" in leafOrNode.view) {
          editor = leafOrNode.view.editor;
        } else if ("editor" in leafOrNode) {
          editor = leafOrNode.editor;
        }
      }

      if(activeView instanceof MarkdownView && activeView.getMode() === "source") {
        editor = activeView.editor;
      }

      if(!editor) {
        return false;
      }

      const field = this.getFieldName(editor);
      if(!field) {
        return false;
      }
      if(checking) {
        return true;
      }
      if(direction === "select") {
        this.addToOntologyModal.show(field);
        return true; 
      }
      this.addFieldToOntology(field,direction);
      return true;
    }

*/

// Group heading - collapsible
/*
      const groupDiv = outerGroupDiv.createDiv(groupDivInfo);
      const groupHeading = groupEl.createDiv('bases-relatednodes-group-heading');
      const iconEl = groupHeading.createSpan('bases-relatednodes-group-heading-icon');
      
      setIcon(iconEl, defaultCollapsed ? 'chevron-right': 'chevron-down'); 
      groupHeading.createSpan({ 
        text: (groupKey || "(ingen #)") 
              + " (" + group.entries.length + ")"
      });
      const groupUl = groupEl.createEl('ul', { 
      cls: defaultCollapsed 
        ? "bases-relatednodes-group-ul collapsed"
        : "bases-relatednodes-group-ul"});
    
      groupHeading.addEventListener('click', () => {
        const collapsed = groupUl.hasClass('collapsed');
        groupUl.toggleClass('collapsed', !collapsed);
        setIcon(iconEl, collapsed ? 'chevron-down' : 'chevron-right')
        groupHeading.parentElement?.querySelectorAll(':scope > ul').forEach(
            (x) => { x.toggleClass('collapsed', !collapsed) }
        )
      });
*/


  // regroup nodes based on first tag of tags in a node
  // sort order: group with highest number of nodes goes first
  private mergeByKey = (items: RelatedNodeGroup[]) => {
    return [...items.reduce((map, item) => {
      const { key, entries } = item;
      if (map.has(key)) {
        // Merge sub-arrays if id exists
        map.get(key).entries.push(...entries);
      } else {
        // Add new item to map
        map.set(key, { ...item, entries: [...entries] });
      }
      return map;
    }, new Map()).values()];
  };



  private forceRefreshByLeafSwitch() {
    const workspace = this.app.workspace;
    const currentLeaf = workspace.activeLeaf;

    if (!currentLeaf) return;

    // 1. Find another leaf to temporarily activate
    // Prefer another markdown leaf in the main area
    let tempLeaf: WorkspaceLeaf | null = null;

    // Option A: Use another existing markdown leaf
    const markdownLeaves = workspace.getLeavesOfType("markdown");
    tempLeaf = markdownLeaves.find(leaf => leaf !== currentLeaf) || null;

    // Option B: If no other markdown leaf, create a temporary empty leaf (safer fallback)
    if (!tempLeaf) {
        tempLeaf = workspace.getLeaf(false);  // false = reuse if possible, don't split
    }

    if (tempLeaf && tempLeaf !== currentLeaf) {
        // Switch away
        workspace.setActiveLeaf(tempLeaf, { focus: true });

        // Immediately switch back (use small timeout to let Obsidian process the change)
        setTimeout(() => {
            if (currentLeaf) {
                workspace.setActiveLeaf(currentLeaf, { focus: true });
            }
            // Optional: call your onDataUpdated after returning
            setTimeout(() => this.onDataUpdated(), 10);
        }, 10);   // 10-30ms is usually enough
    } else {
        // Fallback if we can't find/switch leaves
        this.onDataUpdated();
    }
  }


    // In your view class or wherever you create the note elements
  private attachContextMenu(noteEl: HTMLElement, noteData: NoteProperties) {

      // Desktop: Right Click
      noteEl.addEventListener('contextmenu', (event: MouseEvent) => {
          event.preventDefault();
          event.stopPropagation();
          this.showContextMenu(event, noteData);
      });

      // Mobile: Long Press
      let longPressTimer: number | null = null;

      noteEl.addEventListener('touchstart', (event: TouchEvent) => {
          longPressTimer = window.setTimeout(() => {
              this.showContextMenuForTouch(event, noteData);
          }, 500); // 500ms = standard long press duration
      });

      noteEl.addEventListener('touchend', () => {
          if (longPressTimer) clearTimeout(longPressTimer);
      });

      noteEl.addEventListener('touchmove', () => {
          if (longPressTimer) {
              clearTimeout(longPressTimer);
              longPressTimer = null;
          }
      });
  }

  private showContextMenu(event: MouseEvent, noteData: NoteProperties) {
      const menu = new Menu();

      menu.addItem((item) => {
          item.setTitle("Open Note")
              .setIcon("file-text")
              .onClick(() => {
                  this.app.workspace.openLinkText(noteData.filename, "", false);
              });
      });

      menu.addItem((item) => {
          item.setTitle("Open in New Pane")
              .setIcon("split")
              .onClick(() => {
                  this.app.workspace.openLinkText(noteData.filename, "", true);
              });
      });

      menu.addSeparator();

      menu.addItem((item) => {
          item.setTitle("Copy Name")
              .setIcon("copy")
              .onClick(() => {
                  navigator.clipboard.writeText(noteData.basename);
              });
      });

      // Add more options as needed...

      menu.showAtPosition({ x: event.clientX, y: event.clientY });
  }

  private showContextMenuForTouch(event: TouchEvent, noteData: NoteProperties) {
      // Get position from touch
      const touch = event.touches[0] || event.changedTouches[0];
      
      const menu = new Menu();
      
      // Same menu items as above...
      menu.addItem((item) => item.setTitle("Open Note").setIcon("file-text").onClick(() => {
          this.app.workspace.openLinkText(noteData.filename, "", false);
      }));

      // ... add other items

      menu.showAtPosition({ 
          x: touch!.clientX, 
          y: touch!.clientY 
      });
  }


  /*
const defaultCollapseOptions: BasesOptions = {
		type: 'text', //'text', 'property'
		displayName: 'All collapsed (yes/no)',
		key: 'collapsed',
		default: 'yes',
}
const defaultPropertyOptions: BasesOptions = {
		type: 'property', //'text', 'property'
		displayName: 'default group By property',
		key: 'tags',
		default: 'file.tags',
}
const ignorePropertyOptions: BasesOptions = {
		type: 'property', //'text', 'property'
		displayName: 'ignore following properties',
		key: 'ignore',
		default: '#excalidraw',
}
// neighbour notes  containing these tags are considered 'parents'
const parentTagsOptions: BasesOptions = {
		type: 'text', //'text', 'property'
		displayName: 'parent tags (comma separated, include \'#\')',
		key: 'parentTags',
		default: parentDefaults.join(", ")
}
*/
  
/* callback example

  this.registerResizeMonitors((message) => this.updateHub(message));

*/